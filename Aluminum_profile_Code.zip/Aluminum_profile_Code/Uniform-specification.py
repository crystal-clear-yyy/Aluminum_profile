from PIL import Image
import numpy as np
import cv2
import numpy as np
import matplotlib.pyplot as plt
from scipy import optimize
import os
import math

def errorTransformgood(filepath,imgname):
    image = cv2.imread(filepath)  # 用PIL中的Image.open打开图像
    image_arr = np.array(image)  # 转化成numpy数组
    a = image.shape[0]
    b = image.shape[1]
    print(a, b)
    # a,b=image.siz
    upDianAix = []
    UnderDianAix = []
    # l:高h:宽
    #从上往下，从下往上遍历找第一个白点
    for h in range(0, b):
        for l in range(0, a):
            # print(h)
            if image_arr[l][h][0] >0 and image_arr[l][h][1] >0 and image_arr[l][h][2] >0:

                upDianAix.append([l, h])
                break
    # print(upDianAix)
    for h in range(0, b):
        for l in range(0, a):
            if image_arr[1919 - l][h][0] >0 and image_arr[1919 - l][h][1] >0 and image_arr[1919 - l][h][2] >0:
                UnderDianAix.append([(1919 - l), h])
                break
    #滤除探索错误点
    upSum = 0
    underSum = 0

    #读取x坐标和y坐标点
    for i in range(len(upDianAix)):
        upSum = upSum + upDianAix[i][0]
    upArange = int(upSum / len(upDianAix))

    for i in range(len(UnderDianAix)):
        underSum = underSum + UnderDianAix[i][0]
    underArange = int(underSum / len(UnderDianAix))

        # 拟合点

    y0 = []
    x0 = []
    y1 = []
    x1 = []


    for i in range(0, len(upDianAix)):

        if (upDianAix[i][0] >= upArange):
            y0.append(upDianAix[i][0])
            x0.append(upDianAix[i][1])

    for i in range(0, len(upDianAix)):

        if (UnderDianAix[i][0] <= underArange):
            y1.append(UnderDianAix[i][0])
            x1.append(UnderDianAix[i][1])

    # 绘制散点
    # plt.scatter(x0[:], y0[:], 3, "red")
    def f_1(x, A, B):
        return A * x + B

    # 直线拟合与绘制
    A1, B1 = optimize.curve_fit(f_1, x0, y0)[0]
    A2, B2 = optimize.curve_fit(f_1, x1, y1)[0]

    binaryMap = [[0 for i in range(b)] for i in range(a)]
    binaryMask = [[0 for i in range(b)] for i in range(a)]
    # for h in range(0,b):
    #     for l in range(0,a):
    #         binaryMap[l][h]=[0,0,0]
    #寻找最原始的掩码
    for x in range(0, b):
        for h in range(0, a):
            y1 = int(A1 * x + B1)
            y2 = int(A2 * x + B2) + 1
            if ((h >= y1) & (h <= y2)):
                binaryMap[h][x] = [255, 255, 255]
            else:
                binaryMap[h][x] = [0, 0, 0]
    #边边缩进30像素的掩码
    for x in range(0, b):
        for h in range(0, a):
            y1 = int(A1 * x + B1)
            y2 = int(A2 * x + B2) + 1
            if ((h >= y1+30) & (h <= y2-30)):
                binaryMask[h][x] = [255, 255, 255]
            else:
                binaryMask[h][x] = [0, 0, 0]

    def MatrixToImage(data):
        data = np.array(data)
        new_im = Image.fromarray(data.astype(np.uint8))
        return new_im

    new_im = MatrixToImage(binaryMap)#格式转换  numpy--》图片
    new_mask=MatrixToImage(binaryMask)
    # new_im.show()
    # cv2.imwrite(saveGoodPath,new_im)
    new_im.save(os.path.join(os.getcwd(),f'D:/code/pythonzhangyin/ZY/ZY/until-2.0-imgs-x4.0-new/cropAll/mask-{imgname}'))#保存最原始掩码
    new_mask.save((os.path.join(os.getcwd(),f"D:/code/pythonzhangyin/ZY/ZY/until-2.0-imgs-x4.0-new/cropAll/retract30Mask-{imgname}")))#保存缩进30图片
    return A1,A2

def rotaio(imgpath, imgname, A):
    #图片旋转角度为  最初拟合直线的斜率
    tp = Image.open(imgpath)

    tp.rotate(A).save(f'D:/code/pythonzhangyin/ZY/ZY/until-2.0-imgs-x4.0-new/cropAll/retractImg-{imgname}')  # 旋转任意角度
    mask=Image.open(f"D:/code/pythonzhangyin/ZY/ZY/until-2.0-imgs-x4.0-new/cropAll/retract30Mask-{imgname}")
    mask.rotate(A).save(f"D:/code/pythonzhangyin/ZY/ZY/until-2.0-imgs-x4.0-new/cropAll/retract30Mask-{imgname}")

def crop(imgpath, imgname):
    #裁剪图片
    #按照旋转后的上下边界来裁剪
    img=cv2.imread(imgpath)
    mask=cv2.imread(f"D:/code/pythonzhangyin/ZY/ZY/until-2.0-imgs-x4.0-new/cropAll/retract30Mask-{imgname}")
    upCropLine=0
    underCropLine=0
    for i in range(1920):
         #从横坐标最中间做自上往下，自下往上探索，找到上下边界来裁剪
        if img[i][1280][0]>0 and img[i][1280][1]>0 and img[i][1280][2]>0:
            print(i)
            upCropLine=i
            break
    for i in range(1920):
        if img[1919-i][1280][0]>0 and img[1919-i][1280][1]>0 and img[1919-i][1280][2]>0:
            underCropLine=1919-i
            break
    cropImg=img[upCropLine:underCropLine,0:2560]#按边界裁剪
    cropMask = mask[upCropLine:underCropLine, 0:2560]
    cv2.imwrite(f"D:/code/pythonzhangyin/ZY/ZY/until-2.0-imgs-x4.0-new/cropImg/cropImg-{imgname}",cropImg)#保存裁剪的原始图片
    cv2.imwrite(f"D:/code/pythonzhangyin/ZY/ZY/until-2.0-imgs-x4.0-new/cropMask/cropMask-{imgname}",cropMask)#保存缩进后的掩码图
    cv2.imwrite(f"D:/code/pythonzhangyin/ZY/ZY/until-2.0-imgs-x4.0-new/255-cropMask/cropMask-{imgname}",255-cropMask)#保存缩进后的掩码图

# filepath="mask.png"
# crop(filepath)

if __name__ == '__main__':
    # filepath = "D:/code/EdgeDetection/findLiNE-images-x/findLiNE-images-x1.0/"
    filepath = "D:/code/pythonzhangyin/koutu-images-x/koutu-x-4.0/"

    for images_name in os.listdir(filepath):
        imagepath = filepath + images_name
        A1,A2 = errorTransformgood(imagepath, images_name)#拟合直线 寻找需要的区域 制作掩码
        A = math.degrees(math.atan(A1))#转化数字A---》A°角度
        rotaio(imagepath, images_name, A)#按A°旋转
        # crop('retractImg.png')#裁剪
        crop(f'D:/code/pythonzhangyin/ZY/ZY/until-2.0-imgs-x4.0-new/cropAll/retractImg-{images_name}', images_name)#裁剪
        # crop(f'D:/code/pythonzhangyin/ZY/ZY/until-2.0-imgs/cropAll/retractImg-20180901101040.jpg')#裁剪