import os
import rof
from pylab import *
from PIL import Image
# import scipy.misc
import imageio
import cv2
from skimage import *

# def deNosing(crop, filename, cropname, savePath):
#     if not os.path.exists(savePath+filename):
#       os.mkdir(savePath+filename)
#
#     im1 = array(Image.open(crop).convert("L"))
#     # im1 = array(Image.open(r"D:\code\Adjust_Images\Denoising\test\crop11.jpg").convert("L"))
#     # im2 = array(Image.open(r"C:\Users\DELL\Desktop\ZY\2\crop29.jpg").convert("L"))
#
#     U1, T1 = rof.denoise(im1, im1, tolerance=0.001)
#
#     t1 = 0.8  # flower32_t0 threshold
#     t2 = 0.4  # ceramic-houses_t0 threshold
#     seg_im1 = img_as_uint(U1 < t1 * U1.max())
#
#     # fig = figure()
#     # gray()
#     # subplot(131)
#     # axis('off')
#     # # imshow(im1)
#
#     # subplot(132)
#     # axis('off')
#     cv2.imwrite(f'{savePath + filename}/{cropname}-U1.jpg', U1)
#     # imageio.imsave(f'{savePath + filename}/{cropname}-U1.jpg', U1)
#     # # imshow(U1)
#     #
#     # subplot(133)
#     # axis('off')
#     cv2.imwrite(f'{savePath + filename}/{cropname}-seg_im1.jpg', seg_im1)
#     # imageio.imsave(f'{savePath + filename}/{cropname}-seg_im1.jpg', seg_im1)
#     #
#     # # imshow(seg_im1)
#     # # subplot(234)
#     # # axis('off')
#     # # imshow(im2)
#     #
#     # # subplot(235)
#     # # axis('off')
#     # # # imshow(U2)
#     # #
#     # subplot(236)
#     # axis('off')
#     # # imshow(seg_im2)
#
#     # show()
#
#     # scipy.misc.imsave('../images/ch09/flower32_t0_result.pdf', seg_im)
#     # imageio.imsave('D:/code/Adjust_Images/Denoising/test/flower32_t0_result.pdf', seg_im1)
#     # print("ok")
#     # imageio.imsave('../images/ch09/ceramic-houses_t0_result.pdf', seg_im2)
#     # fig.savefig('../images/ch09/flower32_t0_result.pdf', seg_im1)
#     # fig.savefig('../images/ch09/ceramic-houses_t0_result.pdf', seg_im2)
#
# if __name__ == '__main__':
#     # filePath = "D:/code/Adjust_Images/crop/crop-x4.0-new/"
#     # savePath = "D:/code/Adjust_Images/Denoising/denoising3/crop-x4.0-new-ageio/"
#     filePath = "D:/code/Adjust_Images/Denoising/test/test-in/"
#     savePath = "D:/code/Adjust_Images/Denoising/test/test-out/"
#     for filename in os.listdir(filePath):
#         file = filePath + filename
#         filename_new = filename.replace('-mask.jpg','')   #文件夹名称，即裁剪成crop前的图片名称
#         print(filename_new)
#         for cropName in os.listdir(file):
#             crop = os.path.join(file, cropName)  #裁剪后的crop方块图片地址
#             cropName_new = cropName.replace('.jpg', '')
#             print(cropName_new)
#             deNosing(crop, filename_new, cropName_new, savePath)

im1 = array(Image.open(r'D:\code\Adjust_Images\Denoising\test\1111.jpg').convert("L"))
U1, T1 = rof.denoise(im1, im1, tolerance=0.001)
t1 = 0.8  # flower32_t0 threshold
t2 = 0.4  # ceramic-houses_t0 threshold
seg_im1 = img_as_uint(U1 < t1 * U1.max())
# cv2.imwrite(r'D:\code\Adjust_Images\Denoising\test\test-out\test3-U1.jpg', U1)
# cv2.imwrite(r'D:\code\Adjust_Images\Denoising\test\test-out\test3-seg_im1.jpg', seg_im1)
cv2.imshow('a', seg_im1)
cv2.waitKey()