from PIL import Image
import numpy as np
import cv2
import numpy as np
import matplotlib.pyplot as plt
from scipy import optimize
import os
import math

def errorTransformgood(filepath,savepath,name):
    image = cv2.imread(filepath)  # 用PIL中的Image.open打开图像
    image_arr = np.array(image)  # 转化成numpy数组
    a = image.shape[0]
    b = image.shape[1]
    print(a, b)
    # a,b=image.siz
    upDianAix = []
    UnderDianAix = []
    # l:高h:宽
    for h in range(0, b):
        for l in range(0, a):
            # print(h)
            if (image_arr[l][h][0] == 255 & image_arr[l][h][1] == 255 & image_arr[l][h][2] == 255):
                upDianAix.append([l, h])
                break
    # print(upDianAix)
    for h in range(0, b):
        for l in range(0, a):
            if (image_arr[1919 - l][h][0] == 255 & image_arr[1919 - l][h][1] == 255 & image_arr[1919 - l][h][2] == 255):
                UnderDianAix.append([(1919 - l), h])
                break
    upSum = 0
    underSum = 0
    under1 = UnderDianAix
    up1 = upDianAix
    UnderDianAix = []
    upDianAix = []
    for i in range(0, len(under1)):
        if (int(under1[i][0] - up1[i][0]) > 300):
            UnderDianAix.append(under1[i])
            upDianAix.append(up1[i])

    for i in range(len(upDianAix)):
        upSum = upSum + upDianAix[i][0]
    upArange = int(upSum / len(upDianAix))

    for i in range(len(UnderDianAix)):
        underSum = underSum + UnderDianAix[i][0]
    underArange = int(underSum / len(UnderDianAix))

    def f_1(x, A, B):
        return A * x + B

    # plt.figure()
    # 拟合点
    y0 = []
    x0 = []
    y1 = []
    x1 = []

    for i in range(0, len(upDianAix)):

        if (upDianAix[i][0] >= upArange):
            y0.append(upDianAix[i][0])
            x0.append(upDianAix[i][1])

    for i in range(0, len(upDianAix)):

        if (UnderDianAix[i][0] <= underArange):
            y1.append(UnderDianAix[i][0])
            x1.append(UnderDianAix[i][1])

    # 绘制散点
    # plt.scatter(x0[:], y0[:], 3, "red")

    # 直线拟合与绘制
    A1, B1 = optimize.curve_fit(f_1, x0, y0)[0]
    A2, B2 = optimize.curve_fit(f_1, x1, y1)[0]

    binaryMap = [[0 for i in range(b)] for i in range(a)]
    # for h in range(0,b):
    #     for l in range(0,a):
    #         binaryMap[l][h]=[0,0,0]
    for x in range(0, b):
        for h in range(0, a):
            y1 = int(A1 * x + B1)
            y2 = int(A2 * x + B2) + 1
            if ((h >= y1) & (h <= y2)):
                binaryMap[h][x] = [255, 255, 255]
            else:
                binaryMap[h][x] = [0, 0, 0]

    def MatrixToImage(data):
        data = np.array(data)
        new_im = Image.fromarray(data.astype(np.uint8))
        return new_im

    new_im = MatrixToImage(binaryMap)
    # new_im.show()
    saveGoodPath=os.path.join(savepath,name)
    new_im.save(saveGoodPath)

# 输入二值化图像（第一轮最大连通域图像效果较佳），输出上下线条图像
errorMaskpath=r"D:\code\Superficial_Measure\2new-main-erzhi\2Not_smooth_de"
goodMaskpath=r"D:\code\EdgeDetection\2findLINE-new\2findLINE-de"
errorMasklist=os.listdir(errorMaskpath)
for name in errorMasklist:
    filepath=os.path.join(errorMaskpath,name)
    errorTransformgood(filepath,goodMaskpath,name)



