import cv2 as cv
import numpy as np
import os
def size(img):
    if len(img)%224==0:
        a=len(img)
    else:
        a=(int(len(img)/224)+1)*224
    if len(img[0])%224==0:
        b=len(img[0])
    else:
        b=(int(len(img[0])/224)+1)*224

    img=cv.resize(img,(int(b),int(a)),cv.INTER_CUBIC)
    return img
def cropImg(img,H,W):
    a=H*224
    b=H*224+224
    c=W*224
    d=W*224+224
    imgcrop=img[a:b,c:d]

    return imgcrop
def jiintImg(img,imgCrop,H,W):
    for i in range(0,224):
        for j in range(0,224):
            img[H*224+i][W*224+j][0]=imgCrop[i][j][0]
            img[H * 224 + i][W * 224 + j][1] = imgCrop[i][j][1]
            img[H * 224 + i][W * 224 + j][2] = imgCrop[i][j][2]
    return img

filePath = "D:/code/Adjust_Images/MAXREC/crop-x4.0 - new/"
savepath = "D:/code/Adjust_Images/crop/crop-x4.0-new/"
for img_name in os.listdir(filePath):
    if not os.path.exists(savepath+img_name):
      os.mkdir(savepath+img_name)
    img = cv.imread(filePath+img_name)
    img=size(img)
    print(img.shape)
    originalcrop=[]
    rescrop=[]
    for i in range(int(len(img)/224)*int(len(img[0])/224)):
        H=int(i/int(len(img[0])/224))
        W=int(i%int(len(img[0])/224))
        print(H,W)
        imgcrop=cropImg(img,H,W)
        cv.imwrite(os.path.join(savepath+img_name, 'crop' + str(i) + '.jpg'), imgcrop)