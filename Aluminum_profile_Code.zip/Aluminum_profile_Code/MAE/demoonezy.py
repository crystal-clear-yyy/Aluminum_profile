# import sys
import copy
import os
import os
import cv2
import requests

import matplotlib.pyplot as plt
import torchvision

import torch
import numpy as np
from PIL import Image
import torchvision.transforms as transforms
import models_mae
# from Mask_rate_mask_position import split
# from Mask_rate_mask_position import savedata
# !/usr/bin/env python
# _*_ coding:utf-8 _*_
import torch
from torchvision import utils as vutils
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
# define the utils

imagenet_mean = np.array([0.485, 0.456, 0.406])
imagenet_std = np.array([0.229, 0.224, 0.225])

mean = (0.485, 0.456, 0.406)
std = (0.229, 0.224, 0.225)
def size(img):
    if len(img)%224==0:
        a=len(img)
    else:
        a=(int(len(img)/224)+1)*224
    if len(img[0])%224==0:
        b=len(img[0])
    else:
        b=(int(len(img[0])/224)+1)*224

    img=cv2.resize(img,(int(b),int(a)),cv2.INTER_CUBIC)
    return img
def cropImg(img,H,W):
    a=H*224
    b=H*224+224
    c=W*224
    d=W*224+224
    imgcrop=img[a:b,c:d]

    return imgcrop
def jiintImg(img,imgCrop,H,W):
    for i in range(0,224):
        for j in range(0,224):
            img[H*224+i][W*224+j][0]=imgCrop[i][j][0]
            img[H * 224 + i][W * 224 + j][1] = imgCrop[i][j][1]
            img[H * 224 + i][W * 224 + j][2] = imgCrop[i][j][2]
    return img

def BGR2GRAY(img):
   b = img[:, :, 0].copy()
   g = img[:, :, 1].copy()
   r = img[:, :, 2].copy()

   # Gray scale
   out = 0.2126 * r + 0.7152 * g + 0.0722 * b
   out = out.astype(np.uint8)

   return out

# Otsu Binarization
def otsu_binarization(out,H,W,C,th=0):
   max_sigma = 0
   max_t = 0

   # determine threshold
   for _t in range(1, 255):
      v0 = out[np.where(out < _t)]
      m0 = np.mean(v0) if len(v0) > 0 else 0.
      w0 = len(v0) / (H * W)
      v1 = out[np.where(out >= _t)]
      m1 = np.mean(v1) if len(v1) > 0 else 0.
      w1 = len(v1) / (H * W)
      sigma = w0 * w1 * ((m0 - m1) ** 2)
      if sigma > max_sigma:
         max_sigma = sigma
         max_t = _t

   # Binarization
   print("threshold >>", max_t)
   th = max_t
   out[out < th] = 0
   out[out >= th] = 255

   return out


def save_image_tensor(input_tensor: torch.Tensor, filename):
    """
    将tensor保存为图片
    :param input_tensor: 要保存的tensor
    :param filename: 保存的文件名
    """
    # assert (len(input_tensor.shape) == 4 and input_tensor.shape[0] == 1)
    # 复制一份
    input_tensor = input_tensor.clone().detach()
    # 到cpu
    input_tensor = input_tensor.to(torch.device('cpu'))
    # 反归一化
    # input_tensor = unnormalize(input_tensor)
    vutils.save_image(input_tensor, filename)



# def saveimg(tensor):
#     img = torch.clip((tensor * imagenet_std + imagenet_mean) * 255, 0, 255).int()
#     # print(im_paste[0])
#     m = img.numpy()
#     # n,s=os.path.splitext(filename)
#     # save=os.path.join("filename.jpg",n+'_'+imgname+'-'+s)
#     print(m)
#     cv2.imwrite('D:/code/pythonzhangyin/ZY2.0/reconsitution-images-100/20180901103956/reconstruction.jpg', m)
#     # if cv2.waitKey(0):
#     #     cv2.destroyAllWindows()


def transform_convert(img_tensor, transform):
    """
    param img_tensor: tensor
    param transforms: torchvision.transforms
    """
    if 'Normalize' in str(transform):
        normal_transform = list(filter(lambda x: isinstance(x, transforms.Normalize), transform.transforms))
        mean = torch.tensor(normal_transform[0].mean, dtype=img_tensor.dtype, device=img_tensor.device)
        std = torch.tensor(normal_transform[0].std, dtype=img_tensor.dtype, device=img_tensor.device)
        img_tensor.mul_(std[:, None, None]).add_(mean[:, None, None])

    img_tensor = img_tensor.transpose(0, 2).transpose(0, 1)  # C x H x W  ---> H x W x C

    if 'ToTensor' in str(transform) or img_tensor.max() < 1:
        img_tensor = img_tensor.detach().numpy() * 255

    if isinstance(img_tensor, torch.Tensor):
        img_tensor = img_tensor.numpy()

    if img_tensor.shape[2] == 3:
        img = Image.fromarray(img_tensor.astype('uint8')).convert('RGB')
    elif img_tensor.shape[2] == 1:
        img = Image.fromarray(img_tensor.astype('uint8')).squeeze()
    else:
        raise Exception("Invalid img shape, expected 1 or 3 in axis 2, but got {}!".format(img_tensor.shape[2]))

    return img

def show_image(image, title=''):
    # image is [H, W, 3]
    assert image.shape[2] == 3
    img=(torch.clip((image * imagenet_std + imagenet_mean) * 255, 0, 255).int())
    plt.imshow(img)
    plt.title(title, fontsize=16)
    plt.axis('off')


    plt.gcf().set_size_inches(224 / 100, 224 / 100)
    plt.gca().xaxis.set_major_locator(plt.NullLocator())
    plt.gca().yaxis.set_major_locator(plt.NullLocator())
    plt.subplots_adjust(top=1, bottom=0, right=1, left=0, hspace=0, wspace=0)
    plt.margins(0, 0)

    # plt.savefig(os.path.join(os.getcwd(),title+'.png'))
    plt.savefig(os.path.join('D:/code/pythonzhangyin/ZY2.0/test-demoonezy/loss/20180901141814',title+'.png'))

    return

def prepare_model(chkpt_dir, arch='mae_vit_large_patch16'):#准备模型
    # build model
    model = getattr(models_mae, arch)()
    # load model
    checkpoint = torch.load(chkpt_dir, map_location='cpu')
    msg = model.load_state_dict(checkpoint['model'], strict=False)#向模型加载已经训练好的参数
    print(msg)
    return model


def run_one_image(img, model,k):
    x = torch.tensor(img)
    # make it a batch-like
    x = x.unsqueeze(dim=0)
    x = torch.einsum('nhwc->nchw', x)
    xInput=x
    # maskpos,mask_ratio=split('median.jpg')
    # run MAE
    yS=[]#存放四个重构图
    im_pasteS=[]#存放四个结果图
    maskS=[]#存放四个掩码图
    diffS=[]

    for i in range(4):
        with open("test.txt", "w") as f:
            f.write(str(i))  # 自带文件关闭功能，不需要再写f.close()
        x=xInput

        loss, y, mask = model(x.float(), mask_ratio=0.75)

        print(loss)
        y = model.unpatchify(y)
        y = torch.einsum('nchw->nhwc', y).detach().cpu()

        # visualize the mask
        mask = mask.detach()
        mask = mask.unsqueeze(-1).repeat(1, 1, model.patch_embed.patch_size[0] ** 2 * 3)  # (N, H*W, p*p*3)
        mask = model.unpatchify(mask)  # 1 is removing, 0 is keeping
        mask = torch.einsum('nchw->nhwc', mask).detach().cpu()

        x = torch.einsum('nchw->nhwc', x)

        # masked image
        im_masked = x * (1 - mask)

        # MAE reconstruction pasted with visible patches
        im_paste = x * (1 - mask) + y * mask
        yS.append(y[0])
        im_pasteS.append(im_paste[0])
        maskS.append(im_masked[0])
        diffS.append(im_paste[0]-x[0])
    # fourToOneImg=fourToOne(im_pasteS)
    plt.rcParams['figure.figsize'] = [24, 24]
    plt.subplot(1, 1, 1)
    show_image((im_pasteS[0] + im_pasteS[1] + im_pasteS[2]+ im_pasteS[3] ) /4, "img_crop")


    # plt.subplot(1, 1, 1)
    # show_image((im_pasteS[1]), "prc2")
    # plt.subplot(1, 1, 1)
    # show_image(x[0], "original")

chkpt_dir = "D:\\code\\pythonzhangyin\\ZY2.0\\mae-main\\checkpoint-0-3.pth"#模型:损失结构
model_mae_gan = prepare_model(chkpt_dir, 'mae_vit_large_patch16')
print('Model loaded.')
torch.manual_seed(2)
print('MAE with extra GAN loss:')

# img_url = "D:/code/pythonzhangyin/ZY2.0/reconsitution-images-100/20180907111616-0.2opcv/20180907111616.jpg"
img_url = "D:/code/pythonzhangyin\/ZY/ZY/util-imgs-x-new/cropImgs/cropImg-20180901141814.jpg"
savepath= "D:\\code\\pythonzhangyin\\ZY2.0\\test-demoonezy\\loss\qipan\\20180901101040"
        # img_url = 'https://user-images.githubusercontent.com/11435359/147738734-196fd92f-9260-48d5-ba7e-bf103d29364d.jpg' # cucumber, from ILSVRC2012_val_00047851
        # img = Image.open(requests.get(img_url, stream=True).raw)
img = cv2.imread(img_url)
# img=cv2.resize(img,(448,448))
img=size(img)
print(img.shape)
originalcrop=[]
rescrop=[]
for i in range(int(len(img)/224)*int(len(img[0])/224)):
    H=int(i/int(len(img[0])/224))
    W=int(i%int(len(img[0])/224))
    print(H,W)
    imgcrop=cropImg(img,H,W)
    imgcropcopy = copy.deepcopy(imgcrop)

    cv2.imwrite(os.path.join(savepath, 'crop' + str(i) + '.jpg'), imgcropcopy)
    cv2.imwrite('D:/code/pythonzhangyin/ZY2.0/test-demoonezy/loss/20180901141814/cropimg.png', imgcrop)
    imgcrop = Image.open('D:/code/pythonzhangyin/ZY2.0/test-demoonezy/loss/20180901141814/cropimg.png')
    imgcrop = imgcrop.resize((224, 224))

    originalcrop.append(imgcropcopy)
    # img.save('original.jpg')
    imgcrop = np.array(imgcrop) / 255

    # print(img)
    assert imgcrop.shape == (224, 224, 3)
    plt.rcParams['figure.figsize'] = [5, 5]
    show_image(torch.tensor(imgcrop))
    imgcrop = imgcrop - imagenet_mean
    imgcrop = imgcrop / imagenet_std
    run_one_image(imgcrop, model_mae_gan, str(i))
    imgcrop = cv2.imread('D:/code/pythonzhangyin/ZY2.0/test-demoonezy/loss/20180901141814/cropimg.png')
    rescropcopy = copy.deepcopy(imgcrop)
    cv2.imwrite(os.path.join(savepath,'res'+str(i)+'.jpg'),rescropcopy)
    rescrop.append(imgcropcopy)
    img = jiintImg(img, imgcrop, H, W)
# img=img[:,:,0]

cv2.imwrite(os.path.join(savepath,'res.jpg'),img)










