import cv2
import pdb
import numpy as np
import time
from PIL import Image
import torch
import os
import models_mae
imagenet_mean = np.array([0.485, 0.456, 0.406])
imagenet_std = np.array([0.229, 0.224, 0.225])

def split(path):
    #转换图片格式
    # x = torch.einsum('nchw->nhwc', tensor)
    # img = torch.clip((x[0] * imagenet_std + imagenet_mean) * 255, 0, 255).int()
    # m = img.numpy()
    # cv2.imwrite('tensor.jpg',m)
    # saliency=showSaliency1('tensor.jpg')
    # partimg=partBinary('tensor.jpg')
    # binaryMap=removeLight(partimg,saliency)
    # cv.imwrite('1.jpg',binaryMap)
    # num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(binaryMap, connectivity=8, ltype=None)
    # binary=find_counter(num_labels,labels)
    saliency=cv2.imread(path,0)
    for i in range(len(saliency)):
        for j in range(len(saliency[i])):
            if (saliency[i][j]!=0):
                saliency[i][j]=1
    maskpos,rate=mask_patchify(saliency)
    # savedata(maskpos,rate)
    # print(rate)
    return maskpos



# #寻找图片的显著特征
# def split():
#     # # savepath = 'D:/fabric/result1'
#     # img=cv2.imread('img_url.jpg')
#     # img=cv2.resize(img,(224,224))
#     # H, W, C = img.shape
#     #
#     # # Grayscale
#     # out = BGR2GRAY(img)
#     #
#     # # Otsu's binarization
#     # out = otsu_binarization(out, H, W, C)
#     # cv2.imwrite(savepath,out)
#     #显著后二值化
#     # saliencyAlgorithm = cv2.saliency.StaticSaliencyFineGrained_create()
#     # # 计算显著性
#     # success, saliencyMap = saliencyAlgorithm.computeSaliency(img)
#     # #显著后二值化
#     # _, binaryMap = saliencyAlgorithm.computeBinaryMap(saliencyMap)
#     binaryMap=lcmain()
#     # x = torch.einsum('nchw->nhwc', x)
#     # # x = models_mae.unpatchify(x)
#     # # x = torch.einsum('nchw->nhwc', x).detach().cpu()
#     # img = torch.clip((x[0] * imagenet_std + imagenet_mean) * 255, 0, 255).int()
#     # m=img.numpy()
#     # cv2.imwrite('x.jpg',m)
#     # binaryMap=ft()
#     # binary=np.numpy(binaryMap)
#     # for row in binary:
#     #     row=[]
#     #     for dian in row:
#     #         if(dian[0]>250&dian[1]>250&dian[2]>250):
#     #             dian=1
#
#     #寻找轮廓
#     cv2.imwrite('111.jpg',binaryMap)
#
#     num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(binaryMap, connectivity=8, ltype=None)
#     binary=find_counter(num_labels,labels)
#     maskpos,rate=mask_patchify(binary)
#     # savedata(maskpos,rate)
#     # print(rate)
#     return maskpos

#滤除显著后多余的轮廓
def find_counter(num_labels,labels):
    a = labels.shape[0]
    b = labels.shape[1]

    binary = [[0 for i in range(b)] for i in range(a)]
    allarea = [0 for i in range(num_labels)]
    # print(len(binary))
    # print('开始')
    # for L in range(0, b):
    #     for h in range(0, a):
    #         binary[h][L] = [0,0,0]
    # 寻找每一个连通区域的面积，并判断面积大小
    q = 0

    for L in range(0, b):
        for h in range(0, a):
            if (0 != labels[L][h]):
                # binary[L][h] = 1
                allarea[labels[h][L]] = allarea[labels[h][L]] + 1
    # print(allarea)
    n=0
    for i in range(1, len(allarea)):
        for L in range(0, b):
            for h in range(0, a):
                if (i == labels[h][L]):
                    binary[h][L] =1
    # print(binary)
    # def MatrixToImage(data):
    #     data = np.array(data)
    #     new_im = Image.fromarray(data.astype(np.uint8))
    #     return new_im
    #
    # new_im = MatrixToImage(binary)
    # new_im.show()
    return binary


#掩码分块并寻找缺陷位置
def mask_patchify(binary):
    maskpos=[]
    maskpatch=[0 for i in range(196)]
    j=0
    h=0
    i=0
    k=0
    a=[0,16,32,48,64,80,96,112,128,144,160,176,192,208,224]
    for j in range(14):

        for i in range(14):
            for y in range(a[j], a[j + 1]):
                for x in range(a[i],a[i+1]):
                    # print(x,y)
                    h = h + 1
                    if(binary[y][x]==1):
                        # print(binary[y][x])
                        k=1
            # print(k)
            maskpatch[j*14+i]=k
            k = 0
    # print(maskpos)
    # pdb.set_trace()
    # print(maskpatch)
    for i in range(len(maskpatch)):
        if(maskpatch[i]==0):
            maskpos.append(i)
            j=j+1
    rate=round((196-j)/196)
    # print(maskpos)
    # pdb.set_trace()
    return maskpos,rate

def savedata(maskpos,rate):
    maskpos=maskpos
    rate=rate
    return maskpos,rate

def defectpos(ids_shuffle):
    maskpos,rate=split('median.jpg')
    a=[0 for i in range(len(maskpos))]
    dim0, dim1 = ids_shuffle.shape
    for j in range(len(maskpos)-1):
        for i in range(dim1):
            if (maskpos[j] == ids_shuffle[:, i]): k = i
        a[j]=k
    return a
            # if (n[3] == ids_shuffle[i]): s = i


# import numpy as np
# import time
# import cv2 as cv


def diag_sym_matrix(k=256):
    base_matrix = np.zeros((k, k))
    base_line = np.array(range(k))
    base_matrix[0] = base_line
    for i in range(1, k):
        base_matrix[i] = np.roll(base_line, i)
    base_matrix_triu = np.triu(base_matrix)
    return base_matrix_triu + base_matrix_triu.T


def cal_dist(hist):
    Diag_sym = diag_sym_matrix(k=256)
    hist_reshape = hist.reshape(1, -1)
    hist_reshape = np.tile(hist_reshape, (256, 1))
    return np.sum(Diag_sym * hist_reshape, axis=1)


def LC(image_gray):
    image_height, image_width = image_gray.shape[:2]
    hist_array = cv2.calcHist([image_gray], [0], None, [256], [0.0, 256.0])
    gray_dist = cal_dist(hist_array)

    image_gray_value = image_gray.reshape(1, -1)[0]
    image_gray_copy = [(lambda x: gray_dist[x])(x) for x in image_gray_value]
    image_gray_copy = np.array(image_gray_copy).reshape(image_height, image_width)
    image_gray_copy = (image_gray_copy - np.min(image_gray_copy)) / (np.max(image_gray_copy) - np.min(image_gray_copy))
    return image_gray_copy


def lcmain():
    imgPath = 'originalMask.jpg'
    # imgPath='E:/pyProjects/model/data/sl1/defect/002.png'
    # imgExt = '.jpg'
    # file = r"C:\Users\xxx\Desktop\003.png"

    # start = time.time()
    image_gray = cv2.imread(imgPath, 0)
    image_gray = cv2.resize(image_gray, (224, 224))
    saliency_image = LC(image_gray)

    imgOne = (saliency_image * 255).astype('uint8')
    ret, imgOne = cv2.threshold(imgOne, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    print('峰值为:', ret)  # ret为OTSU算法得出的阈值

    # cv.imwrite(imgPath.replace(imgExt, "lc"+imgExt),saliency_image*255)
    # cv.imwrite(imgPath.replace(imgExt, "lcBinary"+imgExt),imgOne)
    # end = time.time()
    return imgOne
    # print("Duration: %.2f seconds." % (end - start))
    # cv.imshow("gray saliency image", saliency_image)
    # cv.imshow("saliency image binary", imgOne)
    # cv.waitKey(0)
    # cv.destroyAllWindows()
def ft():
    imgPath = 'img_url.jpg'
    # imgPath='E:/pyProjects/model/data/sl1/defect/002.png'
    img = cv2.imread(imgPath)
    img=cv2.resize(img,(224,224))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = cv2.GaussianBlur(img, (7, 7), 0)
    gray_lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)

    l_mean = np.mean(gray_lab[:, :, 0])
    a_mean = np.mean(gray_lab[:, :, 1])
    b_mean = np.mean(gray_lab[:, :, 2])
    lab = np.square(gray_lab - np.array([l_mean, a_mean, b_mean]))
    lab = np.sum(lab, axis=2)
    lab = lab / np.max(lab)
    imgOne = (lab * 255).astype('uint8')
    ret, imgOne = cv2.threshold(imgOne, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    print('峰值为:', ret)  # ret为OTSU算法得出的阈值
    return imgOne
    # plt.imshow(lab, cmap='gray')
    # plt.show()
    # cv2.imshow('result', lab)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()

def BGR2GRAY(img):
   b = img[:, :, 0].copy()
   g = img[:, :, 1].copy()
   r = img[:, :, 2].copy()

   # Gray scale
   out = 0.2126 * r + 0.7152 * g + 0.0722 * b
   out = out.astype(np.uint8)

   return out

# Otsu Binarization
def otsu_binarization(out,H,W,C,th=0):
   max_sigma = 0
   max_t = 0

   # determine threshold
   for _t in range(1, 255):
      v0 = out[np.where(out < _t)]
      m0 = np.mean(v0) if len(v0) > 0 else 0.
      w0 = len(v0) / (H * W)
      v1 = out[np.where(out >= _t)]
      m1 = np.mean(v1) if len(v1) > 0 else 0.
      w1 = len(v1) / (H * W)
      sigma = w0 * w1 * ((m0 - m1) ** 2)
      if sigma > max_sigma:
         max_sigma = sigma
         max_t = _t

   # Binarization
   print("threshold >>", max_t)
   th = max_t
   out[out < th] = 0
   out[out >= th] = 255

   return out
