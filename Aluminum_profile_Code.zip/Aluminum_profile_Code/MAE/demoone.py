# import sys
import os
import os
import cv2
import requests

import matplotlib.pyplot as plt
import torchvision

import torch
import numpy as np
from PIL import Image
import torchvision.transforms as transforms
import models_mae
# from Mask_rate_mask_position import split
# from Mask_rate_mask_position import savedata
# !/usr/bin/env python
# _*_ coding:utf-8 _*_
import torch
from torchvision import utils as vutils
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
# define the utils

imagenet_mean = np.array([0.485, 0.456, 0.406])
imagenet_std = np.array([0.229, 0.224, 0.225])

mean = (0.485, 0.456, 0.406)
std = (0.229, 0.224, 0.225)

def tensor_numpy(image):
    clean = image.clone().detach().cpu().squeeze(0)        # 去掉batch通道 (batch, C, H, W) --> (C, H, W)
    clean[0] = clean[0] * std[0] + mean[0]                 # 数据去归一化
    clean[1] = clean[1] * std[1] + mean[1]
    clean[2] = clean[2].mul(std[2]) + mean[2]
    clean = np.around(clean.mul(255))                     # 转换到颜色255 [0, 1] --> [0, 255]
    clean = np.uint8(clean).transpose(1, 2, 0)            # 跟换三通道 (C, H, W) --> (H, W, C)
    r, g, b = cv2.split(clean)                             # RGB 通道转换
    clean = cv2.merge([b, g, r])
    return clean




def BGR2GRAY(img):
   b = img[:, :, 0].copy()
   g = img[:, :, 1].copy()
   r = img[:, :, 2].copy()

   # Gray scale
   out = 0.2126 * r + 0.7152 * g + 0.0722 * b
   out = out.astype(np.uint8)

   return out

# Otsu Binarization
def otsu_binarization(out,H,W,C,th=0):
   max_sigma = 0
   max_t = 0

   # determine threshold
   for _t in range(1, 255):
      v0 = out[np.where(out < _t)]
      m0 = np.mean(v0) if len(v0) > 0 else 0.
      w0 = len(v0) / (H * W)
      v1 = out[np.where(out >= _t)]
      m1 = np.mean(v1) if len(v1) > 0 else 0.
      w1 = len(v1) / (H * W)
      sigma = w0 * w1 * ((m0 - m1) ** 2)
      if sigma > max_sigma:
         max_sigma = sigma
         max_t = _t

   # Binarization
   print("threshold >>", max_t)
   th = max_t
   out[out < th] = 0
   out[out >= th] = 255

   return out


def save_image_tensor(input_tensor: torch.Tensor, filename):
    """
    将tensor保存为图片
    :param input_tensor: 要保存的tensor
    :param filename: 保存的文件名
    """
    # assert (len(input_tensor.shape) == 4 and input_tensor.shape[0] == 1)
    # 复制一份
    input_tensor = input_tensor.clone().detach()
    # 到cpu
    input_tensor = input_tensor.to(torch.device('cpu'))
    # 反归一化
    # input_tensor = unnormalize(input_tensor)
    vutils.save_image(input_tensor, filename)



def saveimg(tensor):
    img = torch.clip((tensor * imagenet_std + imagenet_mean) * 255, 0, 255).int()
    # print(im_paste[0])
    m = img.numpy()
    # n,s=os.path.splitext(filename)
    # save=os.path.join("filename.jpg",n+'_'+imgname+'-'+s)
    print(m)
    cv2.imwrite('D:/code/pythonzhangyin/ZY2.0/test-demoone/loss/20180901101652-crop40-reconstruction.jpg', m)
    # if cv2.waitKey(0):
    #     cv2.destroyAllWindows()


def transform_convert(img_tensor, transform):
    """
    param img_tensor: tensor
    param transforms: torchvision.transforms
    """
    if 'Normalize' in str(transform):
        normal_transform = list(filter(lambda x: isinstance(x, transforms.Normalize), transform.transforms))
        mean = torch.tensor(normal_transform[0].mean, dtype=img_tensor.dtype, device=img_tensor.device)
        std = torch.tensor(normal_transform[0].std, dtype=img_tensor.dtype, device=img_tensor.device)
        img_tensor.mul_(std[:, None, None]).add_(mean[:, None, None])

    img_tensor = img_tensor.transpose(0, 2).transpose(0, 1)  # C x H x W  ---> H x W x C

    if 'ToTensor' in str(transform) or img_tensor.max() < 1:
        img_tensor = img_tensor.detach().numpy() * 255

    if isinstance(img_tensor, torch.Tensor):
        img_tensor = img_tensor.numpy()

    if img_tensor.shape[2] == 3:
        img = Image.fromarray(img_tensor.astype('uint8')).convert('RGB')
    elif img_tensor.shape[2] == 1:
        img = Image.fromarray(img_tensor.astype('uint8')).squeeze()
    else:
        raise Exception("Invalid img shape, expected 1 or 3 in axis 2, but got {}!".format(img_tensor.shape[2]))

    return img


def show_image(image, title=''):
    # image is [H, W, 3]
    assert image.shape[2] == 3
    img=(torch.clip((image * imagenet_std + imagenet_mean) * 255, 0, 255).int())
    plt.imshow(img)
    plt.title(title, fontsize=16)
    plt.axis('off')


    plt.gcf().set_size_inches(224 / 100, 224 / 100)
    plt.gca().xaxis.set_major_locator(plt.NullLocator())
    plt.gca().yaxis.set_major_locator(plt.NullLocator())
    plt.subplots_adjust(top=1, bottom=0, right=1, left=0, hspace=0, wspace=0)
    plt.margins(0, 0)

    # plt.savefig(os.path.join(os.getcwd(),title+'.png'))
    plt.savefig(os.path.join('D:/code/pythonzhangyin/ZY2.0/test-demoone/loss/', title+'.png'))

    return

def prepare_model(chkpt_dir, arch='mae_vit_large_patch16'):#准备模型
    # build model
    model = getattr(models_mae, arch)()
    # load model
    checkpoint = torch.load(chkpt_dir, map_location='cpu')
    msg = model.load_state_dict(checkpoint['model'], strict=False)#向模型加载已经训练好的参数
    print(msg)
    return model


def run_one_image(img, model):
    x = torch.tensor(img)

    # make it a batch-like
    x = x.unsqueeze(dim=0)
    x = torch.einsum('nhwc->nchw', x)
    # maskpos,mask_ratio=split('median.jpg')
    # run MAE
    loss, y, mask = model(x.float(),mask_ratio=0.95)


    y = model.unpatchify(y)
    y = torch.einsum('nchw->nhwc', y).detach().cpu()

    # visualize the mask
    mask = mask.detach()
    mask = mask.unsqueeze(-1).repeat(1, 1, model.patch_embed.patch_size[0] ** 2 * 3)  # (N, H*W, p*p*3)
    mask = model.unpatchify(mask)  # 1 is removing, 0 is keeping
    mask = torch.einsum('nchw->nhwc', mask).detach().cpu()

    x = torch.einsum('nchw->nhwc', x)

    # masked image
    im_masked = x * (1 - mask)

    # MAE reconstruction pasted with visible patches
    im_paste = x * (1 - mask) + y * mask

    plt.rcParams['figure.figsize'] = [24, 24]
    #
    plt.subplot(1,1, 1)
    show_image(x[0], "20180901101652-crop40-original")
    #
    # #
    # plt.subplot(2,3 , 2)
    # show_image(im_masked[0], "masked")
    # # # #
    # plt.subplot(2, 3, 3)
    # show_image(y[0], "reconstruction")
    # #
    plt.subplot(1,1,1)
    show_image(im_paste[0], "20180901101652-crop40-resv")
    # plt.imshow(im_paste)

    # plt.subplot(2,3,5)
    # show_image(x[0]-im_paste[0], "diff")
    # plt.show()
    # diffImg1=cv2.imread('original.png')
    # diffImg2=cv2.imread('reconstruction + visible.png')
    # diff=cv2.absdiff(diffImg1,diffImg2)
    # cv2.imwrite('diff.jpg',diff)
    # img=cv2.imread('diff.jpg')
    # H, W, C = img.shape
    #
    # # Grayscale
    # out = BGR2GRAY(img)
    #
    # # Otsu's binarization
    # out = otsu_binarization(out,H,W,C)
    # cv2.imshow('2',out)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()


img_url = "D:\\code\\pythonzhangyin\\ZY2.0\\test-demoone\\test-denoising\\20180901101652-crop40.jpg"

        # img_url = 'https://user-images.githubusercontent.com/11435359/147738734-196fd92f-9260-48d5-ba7e-bf103d29364d.jpg' # cucumber, from ILSVRC2012_val_00047851
        # img = Image.open(requests.get(img_url, stream=True).raw)
img=cv2.imread(img_url)
        # img=cv2.resize(img,(224,224))
cv2.imwrite('D:/code/pythonzhangyin/ZY2.0/test-demoone/loss/20180901101652-crop40-median.jpg', img)

img = Image.open('D:/code/pythonzhangyin/ZY2.0/test-demoone/loss/20180901101652-crop40-median.jpg')
# img=img[:,:,0]
img = img.resize((224, 224))
# img.save('original.jpg')
img = np.array(img) / 255

# print(img)
assert img.shape == (224, 224, 3)

        # normalize by ImageNet mean and std
img = img - imagenet_mean
img = img / imagenet_std

plt.rcParams['figure.figsize'] = [5, 5]
show_image(torch.tensor(img))

# chkpt_dir = 'A:\pythonProject\MAE\primary_model\mae_visualize_vit_large.pth'  # 模型地址
# model_mae = prepare_model(chkpt_dir, 'mae_vit_large_patch16')
# print('Model loaded.')
# torch.manual_seed(2)
# print('MAE with pixel reconstruction:')
# run_one_image(img, model_mae)

chkpt_dir = "D:\\code\\pythonzhangyin\\ZY2.0\\mae-main\\checkpoint-0-3.pth" #损失结构
model_mae_gan = prepare_model(chkpt_dir, 'mae_vit_large_patch16')
print('Model loaded.')
torch.manual_seed(2)
print('MAE with extra GAN loss:')
run_one_image(img, model_mae_gan)




