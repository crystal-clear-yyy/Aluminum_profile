import cv2 as cv
import numpy as np
import os
from skimage.metrics import structural_similarity

def size(img):
    if len(img)%WINDOW_SIZE==0:
        a=len(img)
    else:
        a=(int(len(img)/WINDOW_SIZE)+1)*WINDOW_SIZE
    if len(img[0])%WINDOW_SIZE==0:
        b=len(img[0])
    else:
        b=(int(len(img[0])/WINDOW_SIZE)+1)*WINDOW_SIZE

    img=cv.resize(img,(int(b),int(a)),cv.INTER_CUBIC)
    return img
def cropImg(img,H,W):
    a=H*WINDOW_SIZE
    b=H*WINDOW_SIZE+WINDOW_SIZE
    c=W*WINDOW_SIZE
    d=W*WINDOW_SIZE+WINDOW_SIZE
    imgcrop=img[a:b,c:d]

    return imgcrop
def jiintImg(img,imgCrop,H,W):

    for i in range(0,WINDOW_SIZE):
        for j in range(0,WINDOW_SIZE):
            img[H*WINDOW_SIZE+i][W*WINDOW_SIZE+j][0]=255
            img[H * WINDOW_SIZE + i][W * WINDOW_SIZE + j][1] = 255
            img[H * WINDOW_SIZE + i][W * WINDOW_SIZE + j][2] = 255
    return img

filePath=r"D:\code\Adjust_Images\Denoising\denoising3\train-cv2-old"
savePath=r"D:\code\pythonzhangyin\ZY2.0\crop\Mask-undefect"
for name in os.listdir(filePath):
    img_file=os.path.join(filePath, name)
    savePath_new=os.path.join(savePath, name)
    os.makedirs(savePath_new)
    for img_name in os.listdir(img_file):
        imgPath=os.path.join(img_file, img_name)
        # n,s=os.path.splitext(img_name)
        # print(n)
        # print(s)
        # savepath=r"C:\\Users\\DELL\\Desktop\\crop\\4\\"
        # FP=open('A:\pythonProject\MAE\SSIM\SSIM.txt','w')
        WINDOW_SIZE=16
        # for img_name in os.listdir(filePath):
        # if not os.path.exists(savepath+img_name):
        #   os.mkdir(savepath+img_name)
        maskImg = np.zeros((224, 224,3), dtype=np.uint8)
        img = cv.imread(imgPath)
        # resimg=cv.imread(r"D:\Magnetic\res\blowhole\exp1_num_4727.jpg")
        #找最多像素 制作单像素图
        pixel = [0 for i in range(256)]
        grayB = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
        P = 0
        for i in range(len(grayB)):
            for j in range(len(grayB[0])):
                pixel[grayB[i][j]] = 1 + pixel[grayB[i][j]]
        for i in range(len(pixel)):
            if max(pixel) == pixel[i]:
                P = i
                break
        src = np.zeros(((16, 16,3)), np.uint8) + P

        SSIM=[]
        for i in range(int(len(img)/WINDOW_SIZE)*int(len(img[0])/WINDOW_SIZE)):
            H=int(i/int(len(img[0])/WINDOW_SIZE))
            W=int(i%int(len(img[0])/WINDOW_SIZE))
            # print(H,W)
            imgcrop=cropImg(img,H,W)
            # img1crop=cropImg(resimg,H,W)
            (score, diff) = structural_similarity(src, imgcrop, win_size=11, full=True, gaussian_weights=True, sigma=1,multichannel=True)

            if score<0.99:
              jiintImg(maskImg,255,H,W)
            # if i%14==0 and i!=0:
            #     FP.write('\n'+str('%.3f'%float(score))+ '\t')
            # else:
            #     FP.write(str('%.3f'%float(score)) + '\t')

            # if i % 14 == 13:
            #     FP.write(str('%.3f' % float(score)) + '\n')
            # else:
            #     FP.write(str('%.3f' % float(score)) + '\t')
            SSIM.append(score)
        print(SSIM)
        print(min(SSIM))
        # cv.imshow('original',img)
        # cv.imshow('mask',maskImg)
        cv.imwrite(f'{savePath_new}/{img_name}',maskImg)
        cv.waitKey(0)
        cv.destroyAllWindows()

            # print(imgcrop.max())
        #     maskImg=jiintImg(maskImg,imgcrop,H, W)
        # cv.imwrite(savepath+img_name, maskImg)

