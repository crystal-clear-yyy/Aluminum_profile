# import sys
import os
import os
import cv2
import requests

import matplotlib.pyplot as plt
import torchvision

import torch
import numpy as np
from PIL import Image
import torchvision.transforms as transforms
import models_mae
from Mask_rate_mask_position import split

# !/usr/bin/env python
# _*_ coding:utf-8 _*_
import torch
from torchvision import utils as vutils

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
# define the utils

imagenet_mean = np.array([0.485, 0.456, 0.406])
imagenet_std = np.array([0.229, 0.224, 0.225])

mean = (0.485, 0.456, 0.406)
std = (0.229, 0.224, 0.225)


def tensor_numpy(image):
    clean = image.clone().detach().cpu().squeeze(0)  # 去掉batch通道 (batch, C, H, W) --> (C, H, W)
    clean[0] = clean[0] * std[0] + mean[0]  # 数据去归一化
    clean[1] = clean[1] * std[1] + mean[1]
    clean[2] = clean[2].mul(std[2]) + mean[2]
    clean = np.around(clean.mul(255))  # 转换到颜色255 [0, 1] --> [0, 255]
    clean = np.uint8(clean).transpose(1, 2, 0)  # 跟换三通道 (C, H, W) --> (H, W, C)
    r, g, b = cv2.split(clean)  # RGB 通道转换
    clean = cv2.merge([b, g, r])
    return clean


def BGR2GRAY(img):
    b = img[:, :, 0].copy()
    g = img[:, :, 1].copy()
    r = img[:, :, 2].copy()

    # Gray scale
    out = 0.2126 * r + 0.7152 * g + 0.0722 * b
    out = out.astype(np.uint8)

    return out


# Otsu Binarization
def otsu_binarization(out, H, W, C, th=0):
    max_sigma = 0
    max_t = 0

    # determine threshold
    for _t in range(1, 255):
        v0 = out[np.where(out < _t)]
        m0 = np.mean(v0) if len(v0) > 0 else 0.
        w0 = len(v0) / (H * W)
        v1 = out[np.where(out >= _t)]
        m1 = np.mean(v1) if len(v1) > 0 else 0.
        w1 = len(v1) / (H * W)
        sigma = w0 * w1 * ((m0 - m1) ** 2)
        if sigma > max_sigma:
            max_sigma = sigma
            max_t = _t

    # Binarization
    print("threshold >>", max_t)
    th = max_t
    out[out < th] = 0
    out[out >= th] = 255

    return out


def save_image_tensor(input_tensor: torch.Tensor, filename):
    """
    将tensor保存为图片
    :param input_tensor: 要保存的tensor
    :param filename: 保存的文件名
    """
    # assert (len(input_tensor.shape) == 4 and input_tensor.shape[0] == 1)
    # 复制一份
    input_tensor = input_tensor.clone().detach()
    # 到cpu
    input_tensor = input_tensor.to(torch.device('cpu'))
    # 反归一化
    # input_tensor = unnormalize(input_tensor)
    vutils.save_image(input_tensor, filename)


# def saveimg(tensor):
#     img = torch.clip((tensor * imagenet_std + imagenet_mean) * 255, 0, 255).int()
#     # print(im_paste[0])
#     m = img.numpy()
#     # n,s=os.path.splitext(filename)
#     # save=os.path.join("filename.jpg",n+'_'+imgname+'-'+s)
#     print(m)
#     cv2.imwrite('mae-main/reconstruction.jpg', m)
#     # if cv2.waitKey(0):
#     #     cv2.destroyAllWindows()


def transform_convert(img_tensor, transform):
    """
    param img_tensor: tensor
    param transforms: torchvision.transforms
    """
    if 'Normalize' in str(transform):
        normal_transform = list(filter(lambda x: isinstance(x, transforms.Normalize), transform.transforms))
        mean = torch.tensor(normal_transform[0].mean, dtype=img_tensor.dtype, device=img_tensor.device)
        std = torch.tensor(normal_transform[0].std, dtype=img_tensor.dtype, device=img_tensor.device)
        img_tensor.mul_(std[:, None, None]).add_(mean[:, None, None])

    img_tensor = img_tensor.transpose(0, 2).transpose(0, 1)  # C x H x W  ---> H x W x C

    if 'ToTensor' in str(transform) or img_tensor.max() < 1:
        img_tensor = img_tensor.detach().numpy() * 255

    if isinstance(img_tensor, torch.Tensor):
        img_tensor = img_tensor.numpy()

    if img_tensor.shape[2] == 3:
        img = Image.fromarray(img_tensor.astype('uint8')).convert('RGB')
    elif img_tensor.shape[2] == 1:
        img = Image.fromarray(img_tensor.astype('uint8')).squeeze()
    else:
        raise Exception("Invalid img shape, expected 1 or 3 in axis 2, but got {}!".format(img_tensor.shape[2]))

    return img


def show_image(image, title='',savepath=''):
    # image is [H, W, 3]
    assert image.shape[2] == 3
    img = (torch.clip((image * imagenet_std + imagenet_mean) * 255, 0, 255).int())
    plt.imshow(img)
    plt.title(title, fontsize=16)
    plt.axis('off')

    plt.gcf().set_size_inches(224 / 100, 224 / 100)  #效果最好148-152
    plt.gca().xaxis.set_major_locator(plt.NullLocator())
    plt.gca().yaxis.set_major_locator(plt.NullLocator())
    plt.subplots_adjust(top=1, bottom=0, right=1, left=0, hspace=0, wspace=0)
    plt.margins(0, 0)

    plt.savefig(savepath)

    return
def fourToOne(img):
    prcImg=[[[0,0,0] for i in range(224)] for i in range(224)]
    prcImg  = torch.LongTensor(prcImg)
    img[0] = (torch.clip((img[0] * imagenet_std + imagenet_mean) * 255, 0, 255).int())
    img[1] = (torch.clip((img[1] * imagenet_std + imagenet_mean) * 255, 0, 255).int())
    img[2] = (torch.clip((img[2] * imagenet_std + imagenet_mean) * 255, 0, 255).int())
    img[3] = (torch.clip((img[3] * imagenet_std + imagenet_mean) * 255, 0, 255).int())
    # prcImg=img[0]/4+img[1]/4+img[2]/4+img[3]/4
    for i in range(224):
        for j in range(224):
            if i<112 and j<112:
                prcImg[i][j][0] = img[1][i][j][0]
                prcImg[i][j][1] = img[1][i][j][1]
                prcImg[i][j][2] = img[1][i][j][2]
            elif i<112 and j>=112:
                prcImg[i][j][0] = img[0][i][j][0]
                prcImg[i][j][1] = img[0][i][j][1]
                prcImg[i][j][2] = img[0][i][j][2]
            elif i>=112 and j<112:
                prcImg[i][j][0] = img[3][i][j][0]
                prcImg[i][j][1] = img[3][i][j][1]
                prcImg[i][j][2] = img[3][i][j][2]
            else:
                prcImg[i][j][0] = img[2][i][j][0]
                prcImg[i][j][1] = img[2][i][j][1]
                prcImg[i][j][2] = img[2][i][j][2]

            # img = (((prcImg * imagenet_std + imagenet_mean) * 255, 0, 255).int())

    return (prcImg)



def prepare_model(chkpt_dir, arch='mae_vit_large_patch16'):  # 准备模型
    # build model
    model = getattr(models_mae, arch)()
    # load model
    checkpoint = torch.load(chkpt_dir, map_location='cpu')
    msg = model.load_state_dict(checkpoint['model'], strict=False)  # 向模型加载已经训练好的参数
    print(msg)
    return model

def cropImg(img, H, W):
    a = H * 16
    b = H * 16 + 16
    c = W * 16
    d = W * 16 + 16
    imgcrop = img[a:b, c:d]

    return imgcrop

def jiintImg(img, imgCrop, H, W, pixel):
    for i in range(0, 16):
        for j in range(0, 16):
            """
            16-18可以生成一张二值化图，用来观察
             """
            # img[H * 16 + i][W * 16 + j][0] = pixel
            # img[H * 16 + i][W * 16 + j][1] = pixel
            # img[H * 16 + i][W * 16 + j][2] = pixel
            img[H * 16 + i][W * 16 + j][0] = imgCrop[i][j][0]
            img[H * 16 + i][W * 16 + j][1] = imgCrop[i][j][1]
            img[H * 16 + i][W * 16 + j][2] = imgCrop[i][j][2]
    return img

def two_to_one(imgName, filename):
    # 21--39 75+25

    img_75 = r'D:\code\contrast\MAE\1.jpg'
    img_25 = r"D:\code\contrast\MAE\2.jpg"
    img_save = f"D:/code/contrast/MAE/recon-x/{filename}"
    isExists = os.path.exists(img_save)
    if not isExists:
        os.makedirs(img_save)
        Img75 = cv2.imread(img_75)  # 没有东西的图片
        Img25 = cv2.imread(img_25)  # 有东西的图片
        newimg = np.zeros(Img75.shape, np.uint8)
        for i in range(196):
            if (i % 4 == 0):
                imgcrop = cropImg(Img25, int(i / 14), i % 14)
                img = jiintImg(newimg, imgcrop, int(i / 14), i % 14, pixel=0)
            else:
                imgcrop = cropImg(Img75, int(i / 14), i % 14)
                img = jiintImg(newimg, imgcrop, int(i / 14), i % 14, pixel=255)
        cv2.imwrite(os.path.join(img_save, imgName), img)
        return True
    else:
        # originalImg = cv2.imread("G:/total/total_defect224/SL1_000.png")
        """
        originalImg:放进模型的图片
        Img75：重构75%
        Img25：重构25%
        """

        Img75 = cv2.imread(img_75)  # 没有东西的图片
        Img25 = cv2.imread(img_25)  # 有东西的图片
        newimg = np.zeros(Img75.shape, np.uint8)
        for i in range(196):
            if (i % 4 == 0):
                imgcrop = cropImg(Img25, int(i / 14), i % 14)
                img = jiintImg(newimg, imgcrop, int(i / 14), i % 14, pixel=0)
            else:
                imgcrop = cropImg(Img75, int(i / 14), i % 14)
                img = jiintImg(newimg, imgcrop, int(i / 14), i % 14, pixel=255)

        cv2.imwrite(os.path.join(img_save, imgName), img)
        # cv.imwrite("1.jpg",img)
        return False

def run_one_image(img, model, imgName, filename):
    x = torch.tensor(img)
    # make it a batch-like
    x = x.unsqueeze(dim=0)
    x = torch.einsum('nhwc->nchw', x)
    xInput=x
    # maskpos,mask_ratio=split('median.jpg')
    # run MAE
    yS=[]#存放四个重构图
    im_pasteS=[]#存放四个结果图
    maskS=[]#存放四个掩码图
    diffS=[]
    # lossS=[]
    for i in range(2):
        with open("test.txt", "w") as f:
            f.write(str(i))  # 自带文件关闭功能，不需要再写f.close()
        x=xInput

        loss, y, mask = model(x.float(), mask_ratio=0.75)
        # lossS.append(loss)
        print('jieshu')
        y = model.unpatchify(y)
        y = torch.einsum('nchw->nhwc', y).detach().cpu()

        # visualize the mask
        mask = mask.detach()
        mask = mask.unsqueeze(-1).repeat(1, 1, model.patch_embed.patch_size[0] ** 2 * 3)  # (N, H*W, p*p*3)
        mask = model.unpatchify(mask)  # 1 is removing, 0 is keeping
        mask = torch.einsum('nchw->nhwc', mask).detach().cpu()

        x = torch.einsum('nchw->nhwc', x)

        # masked image
        im_masked = x * (1 - mask)

        # MAE reconstruction pasted with visible patches
        im_paste = x * (1 - mask) + y * mask
        yS.append(y[0])
        im_pasteS.append(im_paste[0])
        maskS.append(im_masked[0])
        diffS.append(im_paste[0]-x[0])
        if i==0:
            plt.rcParams['figure.figsize'] = [24, 24]
            plt.subplot(1, 1, 1)
            show_image(im_pasteS[0], imgName,savepath='D:/code/contrast/MAE/1.jpg')
        else:
            plt.rcParams['figure.figsize'] = [24, 24]
            plt.subplot(1, 1, 1)
            show_image(im_pasteS[1], imgName,savepath='D:/code/contrast/MAE/2.jpg')
    two_to_one(imgName, filename)

    # fourToOneImg=fourToOne(im_pasteS)
    # plt.rcParams['figure.figsize'] = [24, 24]
    # plt.subplot(1, 1, 1)
    # show_image((im_pasteS[0] + im_pasteS[1] + im_pasteS[2] + im_pasteS[3]) / 4, name)
    # loss=((lossS[0]+lossS[1]+lossS[2]+lossS[3])/4)
    # file.write(str(float(loss.data))+'\n')
    #
    # for i in range(len(maskS)):
    #     plt.subplot(4, 5, i*5+1)
    #     show_image(x[0], "ori")
    #     #
    #     # #
    #     plt.subplot(4, 5, i*5+2)
    #     show_image(maskS[i], "masked")
    #     # #
    #     plt.subplot(4, 5, i*5+3)
    #     show_image(yS[i], "重构")
    #     # #
    #     plt.subplot(4, 5, i*5+4)
    #     show_image(im_pasteS[i], "rel")
    #
    #     plt.subplot(4, 5, i*5+5)
    #     show_image((im_pasteS[0]+im_pasteS[1]+im_pasteS[2]+im_pasteS[3])/4, "result")


    # # plt.imshow(im_paste)
    #
    # # plt.subplot(2,3,5)
    # # show_image(x[0]-im_paste[0], "diff")
    # plt.show()
    # fourToOneImg = fourToOne(diffS)
    # plt.subplot(1,1,1)
    # show_image(x[0], "original")
    # plt.gcf().set_size_inches(224 / 100, 224 / 100)
    # plt.gca().xaxis.set_major_locator(plt.NullLocator())
    # plt.gca().yaxis.set_major_locator(plt.NullLocator())
    # plt.subplots_adjust(top=1, bottom=0, right=1, left=0, hspace=0, wspace=0)
    # plt.margins(0, 0)
    #
    # plt.savefig(os.path.join(os.getcwd(),'original'+'.png'))
    #
    # plt.subplot(1,1,1)
    # show_image(fourToOneImg, "rec")
    #
    # plt.subplot(1, 3, 3)
    # show_image(abs(x[0]-fourToOneImg)*255, "diff")

    # plt.rcParams['figure.figsize'] = [24, 24]
    # plt.subplot(1,3,1)
    # plt.imshow(x[0])
    # plt.title('title1', fontsize=16)
    # plt.axis('off')
    #展示四合一
    # MES = fourToOne(im_pasteS)
    # plt.subplot(1, 1, 1)
    # plt.imshow(MES)
    # plt.title('title2', fontsize=16)
    # plt.axis('off')
    # # plt.show()
    # plt.gcf().set_size_inches(224 / 100, 224 / 100)
    # plt.gca().xaxis.set_major_locator(plt.NullLocator())
    # plt.gca().yaxis.set_major_locator(plt.NullLocator())
    # plt.subplots_adjust(top=1, bottom=0, right=1, left=0, hspace=0, wspace=0)
    # plt.margins(0, 0)
    # #
    # plt.savefig(os.path.join(os.getcwd(), 'rec' + '.png'))
    #差分
    # diffImg1=cv2.imread('original.png')
    # diffImg2=cv2.imread('rec.png')
    # diff=cv2.absdiff(diffImg1,diffImg2)
    # # cv2.imwrite('diff.jpg',diff)
    # cv2.imshow('diff',diff)
    # img=cv2.imread('diff.jpg')
    # plt.subplot(1, 3, 3)
    # plt.imshow(abs(fourToOneImg - x[0]))
    # plt.title('title3', fontsize=16)
    # plt.axis('off')
    # plt.show()
    # plt.subplot(1, 1, 1)
    # show_image(fourToOneImg, "fo")
    # plt.show()

    # diffImg1=cv2.imread('original.png')
    # diffImg2=cv2.imread('reconstruction + visible.png')
    # diff=cv2.absdiff(diffImg1,diffImg2)
    # cv2.imwrite('diff.jpg',diff)
    #二值化
    # img=cv2.imread('rec.png')
    # H, W, C = img.shape
    # #
    # # # Grayscale
    # out = BGR2GRAY(img)
    #
    # # Otsu's binarization
    # out = otsu_binarization(out,H,W,C)
    # cv2.imshow('2',out)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()

chkpt_dir = r"D:\code\pythonzhangyin\ZY2.0\mae-main\checkpoint-0-0.pth"# 第二个模型
# chkpt_dir = 'E:\python project\mae_basetrain\output_dir\large_checkpoint-80no1.pth'  # 第二个模型
model_mae_gan = prepare_model(chkpt_dir, 'mae_vit_large_patch16')
print('Model loaded.')
torch.manual_seed(2)
print('MAE with extra GAN loss:')
# file = open('G:/loss.txt','w')
img_url = r"D:\code\contrast\MAE\crop-x4.0-new\0"
# savepath = "G:/test/result"
list=os.listdir(img_url)
for name in list:
    # n,s=os.path.splitext(name)
    img_file=os.path.join(img_url,name)
    for img_name in os.listdir(img_file):
        imgpath=os.path.join(img_file,img_name)
        img_old = cv2.imread(imgpath)
        cv2.imwrite(f"D:/code/contrast/MAE/median-x/{img_name}", img_old)
        # img = Image.open(imgpath)
        img = Image.open(f"D:/code/contrast/MAE/median-x/{img_name}")
        # img=img[:,:,0]
        img = img.resize((224, 224))
        # img.save('original.jpg')
        img = np.array(img) / 255

        # print(img)
        assert img.shape == (224, 224, 3)

        # normalize by ImageNet mean and std
        img = img - imagenet_mean
        img = img / imagenet_std

        plt.rcParams['figure.figsize'] = [5, 5]
        show_image(torch.tensor(img))

        # chkpt_dir = 'A:\pythonProject\MAE\primary_model\mae_visualize_vit_large.pth'  # 模型地址
        # model_mae = prepare_model(chkpt_dir, 'mae_vit_large_patch16')
        # print('Model loaded.')
        # torch.manual_seed(2)
        # print('MAE with pixel reconstruction:')
        # run_one_image(img, model_mae)

        run_one_image(img, model_mae_gan, img_name, name)